package com.zryalya.pemikiran;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONObject;

public class Sched {
    static final String CH = "jadwal";
    // Default: ingatkan 15 menit sebelum, dan tepat saat kuliah dimulai
    static final int MENIT = 15;
    static final String DEF_OFFSETS = "15,0";

    static final Pattern P = Pattern.compile(
        "(Senin|Selasa|Rabu|Kamis|Jumat|Sabtu|Minggu):|\\[\"((\\d{1,2})[.:](\\d{2})[^\"]*)\",\"((?:[^\"\\\\]|\\\\.)*)\"\\]");
    static final Pattern T = Pattern.compile("(\\d{1,2})[.:](\\d{2})");

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("p", 0);
    }

    static int dayNum(String d) {
        switch (d) {
            case "Minggu": return Calendar.SUNDAY;
            case "Senin": return Calendar.MONDAY;
            case "Selasa": return Calendar.TUESDAY;
            case "Rabu": return Calendar.WEDNESDAY;
            case "Kamis": return Calendar.THURSDAY;
            case "Jumat": return Calendar.FRIDAY;
            case "Sabtu": return Calendar.SATURDAY;
        }
        return -1;
    }

    static String readIndex(Context c) throws Exception {
        InputStream in = c.getAssets().open("index.html");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    // Daftar "menit sebelum kuliah" dari pengaturan, mis. "30,15,5,0"
    static int[] offsets(Context c) {
        String s = prefs(c).getString("offsets", DEF_OFFSETS);
        List<Integer> l = new ArrayList<Integer>();
        for (String x : s.split(",")) {
            try {
                int v = Integer.parseInt(x.trim());
                if (v >= 0 && v <= 1440 && !l.contains(v) && l.size() < 10) l.add(v);
            } catch (Exception e) { }
        }
        if (l.isEmpty()) l.add(MENIT);
        int[] r = new int[l.size()];
        for (int i = 0; i < r.length; i++) r[i] = l.get(i);
        return r;
    }

    static void cancelAll(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            for (int code = 1000; code < 2100; code++) {
                PendingIntent p = PendingIntent.getBroadcast(c, code,
                    new Intent(c, AlarmReceiver.class),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                if (p != null) { am.cancel(p); p.cancel(); }
            }
        } catch (Exception e) { }
    }

    static void scheduleClass(Context c, int day, int h, int mi, String range,
                              String name, int idx, int[] offs) {
        for (int oi = 0; oi < offs.length; oi++) {
            schedule(c, day, h, mi, range, name, 1000 + idx * 10 + oi, offs[oi]);
        }
    }

    // Jadwal dari WebView (termasuk yang diedit pengguna di Pengaturan halaman)
    static boolean scheduleJson(Context c, String json) {
        try {
            JSONObject o = new JSONObject(json);
            SharedPreferences sp = prefs(c);
            if (!sp.getBoolean("enabled", true)) return true;
            Set<String> muted = sp.getStringSet("muted", new HashSet<String>());
            int[] offs = offsets(c);
            int idx = 0;
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String d = it.next();
                int day = dayNum(d);
                if (day < 0) continue;
                JSONArray a = o.getJSONArray(d);
                for (int k = 0; k < a.length() && idx < 100; k++) {
                    JSONArray r = a.getJSONArray(k);
                    String range = r.getString(0);
                    String name = r.getString(1);
                    if (muted.contains(d + "|" + range + "|" + name)) continue;
                    Matcher m = T.matcher(range);
                    if (!m.find()) continue;
                    scheduleClass(c, day, Integer.parseInt(m.group(1)),
                        Integer.parseInt(m.group(2)), range, name, idx, offs);
                    idx++;
                }
            }
            return true;
        } catch (Exception e) { return false; }
    }

    static void saveAndSchedule(Context c, String json) {
        prefs(c).edit().putString("jadwal", json).apply();
        cancelAll(c);
        scheduleJson(c, json);
    }

    static void scheduleAll(Context c) {
        String js = prefs(c).getString("jadwal", null);
        cancelAll(c);
        if (js != null && scheduleJson(c, js)) return;
        if (!prefs(c).getBoolean("enabled", true)) return;
        scheduleFromHtml(c);
    }

    // Cadangan: baca jadwal langsung dari JADWAL di index.html
    static void scheduleFromHtml(Context c) {
        try {
            String html = readIndex(c);
            int s = html.indexOf("JADWAL={");
            if (s < 0) return;
            int e = html.indexOf("};", s);
            if (e < 0) return;
            int[] offs = offsets(c);
            Matcher m = P.matcher(html.substring(s, e + 1));
            int day = -1;
            int idx = 0;
            while (m.find()) {
                if (m.group(1) != null) {
                    day = dayNum(m.group(1));
                    continue;
                }
                if (day < 0 || idx >= 100) continue;
                String name = m.group(5).replace("\\'", "'").replace("\\\"", "\"");
                scheduleClass(c, day, Integer.parseInt(m.group(3)),
                    Integer.parseInt(m.group(4)), m.group(2), name, idx, offs);
                idx++;
            }
        } catch (Exception e) { }
    }

    static long next(int day, int h, int m, int offset) {
        long now = System.currentTimeMillis();
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, h);
        c.set(Calendar.MINUTE, m);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        for (int d = 0; d < 9; d++) {
            if (c.get(Calendar.DAY_OF_WEEK) == day) {
                long trig = c.getTimeInMillis() - offset * 60000L;
                if (trig > now + 1000) return trig;
            }
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        return -1;
    }

    static void schedule(Context c, int day, int h, int m, String range, String name, int code, int offset) {
        try {
            long when = next(day, h, m, offset);
            if (when < 0) return;
            Intent i = new Intent(c, AlarmReceiver.class);
            i.putExtra("day", day);
            i.putExtra("h", h);
            i.putExtra("m", m);
            i.putExtra("range", range);
            i.putExtra("name", name);
            i.putExtra("code", code);
            i.putExtra("offset", offset);
            PendingIntent p = PendingIntent.getBroadcast(c, code, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            if (exact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
            }
        } catch (Exception e) { }
    }

    static void notify(Context c, String title, String text, int id) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH, "Jadwal Kuliah", NotificationManager.IMPORTANCE_HIGH));
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, CH)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(new Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build();
        nm.notify(id, n);
    }
}
