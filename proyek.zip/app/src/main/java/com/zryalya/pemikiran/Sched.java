package com.zryalya.pemikiran;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Sched {
    static final String CH = "jadwal";
    // Pengingat muncul sekian menit sebelum kelas dimulai
    static final int MENIT = 15;

    static final Pattern P = Pattern.compile(
        "(Senin|Selasa|Rabu|Kamis|Jumat|Sabtu|Minggu):|\\[\"((\\d{1,2})[.:](\\d{2})[^\"]*)\",\"((?:[^\"\\\\]|\\\\.)*)\"\\]");

    static int dayNum(String d) {
        switch (d) {
            case "Minggu": return Calendar.SUNDAY;
            case "Senin": return Calendar.MONDAY;
            case "Selasa": return Calendar.TUESDAY;
            case "Rabu": return Calendar.WEDNESDAY;
            case "Kamis": return Calendar.THURSDAY;
            case "Jumat": return Calendar.FRIDAY;
            case "Sabtu": return Calendar.SATURDAY;
        }
        return -1;
    }

    static String readIndex(Context c) throws Exception {
        InputStream in = c.getAssets().open("index.html");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    // Membaca jadwal langsung dari const JADWAL di index.html
    static void scheduleAll(Context c) {
        try {
            String html = readIndex(c);
            int s = html.indexOf("const JADWAL=");
            if (s < 0) return;
            int e = html.indexOf("};", s);
            if (e < 0) return;
            Matcher m = P.matcher(html.substring(s, e + 1));
            int day = -1;
            int idx = 0;
            while (m.find()) {
                if (m.group(1) != null) {
                    day = dayNum(m.group(1));
                    continue;
                }
                if (day < 0) continue;
                String name = m.group(5).replace("\\'", "'").replace("\\\"", "\"");
                int h = Integer.parseInt(m.group(3));
                int mi = Integer.parseInt(m.group(4));
                // 1) pengingat sebelum kelas, 2) notifikasi tepat saat kelas dimulai
                schedule(c, day, h, mi, m.group(2), name, 1000 + idx, MENIT);
                schedule(c, day, h, mi, m.group(2), name, 2000 + idx, 0);
                idx++;
            }
        } catch (Exception e) { }
    }

    static long next(int day, int h, int m, int offset) {
        long now = System.currentTimeMillis();
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, h);
        c.set(Calendar.MINUTE, m);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        for (int d = 0; d < 8; d++) {
            if (c.get(Calendar.DAY_OF_WEEK) == day) {
                long trig = c.getTimeInMillis() - offset * 60000L;
                if (trig > now + 1000) return trig;
            }
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        return -1;
    }

    static void schedule(Context c, int day, int h, int m, String range, String name, int code, int offset) {
        try {
            long when = next(day, h, m, offset);
            if (when < 0) return;
            Intent i = new Intent(c, AlarmReceiver.class);
            i.putExtra("day", day);
            i.putExtra("h", h);
            i.putExtra("m", m);
            i.putExtra("range", range);
            i.putExtra("name", name);
            i.putExtra("code", code);
            i.putExtra("offset", offset);
            PendingIntent p = PendingIntent.getBroadcast(c, code, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            if (exact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
            }
        } catch (Exception e) { }
    }

    static void notify(Context c, String title, String text, int id) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH, "Jadwal Kuliah", NotificationManager.IMPORTANCE_HIGH));
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, CH)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(new Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build();
        nm.notify(id, n);
    }
}
