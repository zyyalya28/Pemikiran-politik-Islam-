package com.zryalya.pemikiran;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONTokener;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#0a0818"));
        getWindow().setNavigationBarColor(Color.parseColor("#0a0818"));
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        Sched.scheduleAll(this);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0a0818"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) { syncJadwal(); }
        });
        FrameLayout fl = new FrameLayout(this);
        fl.addView(web, new FrameLayout.LayoutParams(-1, -1));
        float d = getResources().getDisplayMetrics().density;
        TextView fab = new TextView(this);
        fab.setText("\u23F0");
        fab.setTextSize(22);
        fab.setGravity(Gravity.CENTER);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(Color.parseColor("#E62a2550"));
        fab.setBackground(gd);
        fab.setElevation(8 * d);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AlarmSettingsActivity.class));
            }
        });
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) (52 * d), (int) (52 * d),
            Gravity.BOTTOM | Gravity.END);
        lp.setMargins(0, 0, (int) (16 * d), (int) (24 * d));
        fl.addView(fab, lp);
        setContentView(fl);
        web.loadUrl("file:///android_asset/index.html");
    }

    // Ambil jadwal terbaru dari halaman (termasuk hasil edit) lalu jadwalkan ulang notifikasi
    private void syncJadwal() {
        web.evaluateJavascript(
            "(function(){try{return JSON.stringify(JADWAL)}catch(e){return ''}})()",
            v -> {
                try {
                    if (v == null || v.equals("null")) return;
                    Object o = new JSONTokener(v).nextValue();
                    if (o instanceof String && ((String) o).startsWith("{")) {
                        Sched.saveAndSchedule(MainActivity.this, (String) o);
                    }
                } catch (Exception e) { }
            });
    }

    @Override
    protected void onPause() {
        super.onPause();
        syncJadwal();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
