package com.zryalya.pemikiran;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

public class AlarmSettingsActivity extends Activity {
    private final List<CheckBox> boxes = new ArrayList<CheckBox>();
    private final List<String> keys = new ArrayList<String>();
    private Switch sw;
    private EditText et;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String t, int sp, boolean bold, int color) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(null, android.graphics.Typeface.BOLD);
        tv.setPadding(0, dp(10), 0, dp(4));
        return tv;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#0a0818"));
        getWindow().setNavigationBarColor(Color.parseColor("#0a0818"));
        SharedPreferences sp = Sched.prefs(this);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#0a0818"));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(32));
        sv.addView(root);

        int white = Color.WHITE;
        int grey = Color.parseColor("#b8b4d0");

        root.addView(text("Pengaturan Alarm Kuliah", 22, true, white));

        sw = new Switch(this);
        sw.setText("Aktifkan alarm jadwal kuliah");
        sw.setTextColor(white);
        sw.setChecked(sp.getBoolean("enabled", true));
        sw.setPadding(0, dp(12), 0, dp(12));
        root.addView(sw);

        root.addView(text("Waktu pengingat", 16, true, white));
        root.addView(text("Berapa menit sebelum kuliah dimulai? Boleh lebih dari satu, "
            + "pisahkan dengan koma. Isi 0 untuk notifikasi tepat saat kuliah dimulai. "
            + "Contoh: 30,15,5,0", 13, false, grey));
        et = new EditText(this);
        et.setText(sp.getString("offsets", Sched.DEF_OFFSETS));
        et.setTextColor(white);
        et.setHintTextColor(grey);
        et.setHint("15,0");
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        et.setSingleLine(true);
        root.addView(et);

        root.addView(text("Alarm per mata kuliah", 16, true, white));
        root.addView(text("Hilangkan centang untuk mematikan alarm mata kuliah tertentu.", 13, false, grey));

        Set<String> muted = sp.getStringSet("muted", new HashSet<String>());
        String js = sp.getString("jadwal", null);
        boolean any = false;
        try {
            if (js != null) {
                JSONObject o = new JSONObject(js);
                String[] days = {"Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"};
                for (String d : days) {
                    if (!o.has(d)) continue;
                    JSONArray a = o.getJSONArray(d);
                    for (int k = 0; k < a.length(); k++) {
                        JSONArray r = a.getJSONArray(k);
                        String range = r.getString(0);
                        String name = r.getString(1);
                        String key = d + "|" + range + "|" + name;
                        CheckBox cb = new CheckBox(this);
                        cb.setText(d + " \u2022 " + range + "\n" + name);
                        cb.setTextColor(white);
                        cb.setChecked(!muted.contains(key));
                        cb.setPadding(0, dp(6), 0, dp(6));
                        root.addView(cb);
                        boxes.add(cb);
                        keys.add(key);
                        any = true;
                    }
                }
            }
        } catch (Exception e) { }
        if (!any) {
            root.addView(text("Jadwal belum terbaca. Buka halaman utama aplikasi sekali, "
                + "lalu kembali ke sini.", 13, false, grey));
        }

        Button save = new Button(this);
        save.setText("Simpan");
        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { save(); }
        });
        root.addView(save);

        Button test = new Button(this);
        test.setText("Tes notifikasi");
        test.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Sched.notify(AlarmSettingsActivity.this, "Tes alarm kuliah",
                    "Notifikasi berfungsi dengan baik", 999);
            }
        });
        root.addView(test);

        setContentView(sv);
    }

    private void save() {
        String raw = et.getText().toString();
        List<Integer> l = new ArrayList<Integer>();
        for (String x : raw.split(",")) {
            String t = x.trim();
            if (t.length() == 0) continue;
            try {
                int v = Integer.parseInt(t);
                if (v < 0 || v > 1440) throw new NumberFormatException();
                if (!l.contains(v)) l.add(v);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Isi angka 0-1440 dipisah koma, mis. 30,15,0",
                    Toast.LENGTH_LONG).show();
                return;
            }
        }
        if (l.isEmpty()) {
            Toast.makeText(this, "Isi minimal satu waktu pengingat", Toast.LENGTH_LONG).show();
            return;
        }
        if (l.size() > 10) {
            Toast.makeText(this, "Maksimal 10 waktu pengingat", Toast.LENGTH_LONG).show();
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(l.get(i));
        }
        Set<String> muted = new HashSet<String>();
        for (int i = 0; i < boxes.size(); i++) {
            if (!boxes.get(i).isChecked()) muted.add(keys.get(i));
        }
        Sched.prefs(this).edit()
            .putBoolean("enabled", sw.isChecked())
            .putString("offsets", sb.toString())
            .putStringSet("muted", muted)
            .apply();
        Sched.scheduleAll(this);
        Toast.makeText(this, "Tersimpan", Toast.LENGTH_SHORT).show();
        finish();
    }
}
