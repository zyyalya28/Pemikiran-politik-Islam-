package com.zryalya.pemikiran;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        try {
            int day = i.getIntExtra("day", -1);
            int h = i.getIntExtra("h", 0);
            int m = i.getIntExtra("m", 0);
            int code = i.getIntExtra("code", 1000);
            String range = i.getStringExtra("range");
            String name = i.getStringExtra("name");
            Sched.notify(c, "Kuliah: " + name,
                "Jam " + range + " (" + Sched.MENIT + " menit lagi)", code);
            Sched.schedule(c, day, h, m, range, name, code);
        } catch (Exception e) { }
    }
}
